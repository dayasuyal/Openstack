<!--
Please do not ask questions here. 
For that refer to https://groups.google.com/forum/#!forum/search-guard

Github is a place only for reporting bugs or feature requests.
If you report a bug please include always the following informations:

* Search Guard and Elasticsearch version
* JVM version and operating system version
* Number of nodes in your cluster
* Description of the bug

These informations are optional but are very valueable and
typically would lead to get bugs fixed faster:

* Steps to reproduce
* Logfiles on DEBUG level
-->
